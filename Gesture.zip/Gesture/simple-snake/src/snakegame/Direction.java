package snakegame;

public enum Direction {
	
	NORTH,
	
	SOUTH,
	
	EAST,
	
	WEST
	
}
